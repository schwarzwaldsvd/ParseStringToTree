﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParseStringToTree
{
    class Program
    {

        static void Main()
        {
            string inputString = "(id, name, email, type(id, name, customFields(c1, c2, c3)), externalId)";
            Node rootNode = new Node
            {
                Parent = null,
                Value = String.Empty,
                SubNodes = new List<Node>()
            };
            Node node = rootNode;
            bool escape = false;
            foreach (char c in inputString)
            {
                if (escape)
                {
                    if (c != ' ') node.Value += c;
                    escape = false;
                }
                else
                {
                    switch (c)
                    {
                        case '(' :
                            node = new Node {Parent = node, Value = String.Empty, SubNodes = new List<Node>()};
                            node.Parent.SubNodes.Add(node);
                            break;
                        case ')' :
                            if (node.Parent != null)
                            {
                                node = new Node {Parent = node.Parent.Parent, Value = String.Empty, SubNodes = new List<Node>()};
                                node.Parent?.SubNodes.Add(node);
                            }

                            break;
                        case ',':
                            node = new Node { Parent = node.Parent, Value = String.Empty, SubNodes = new List<Node>() };
                            node.Parent?.SubNodes.Add(node);
                            escape = true;
                            break;
                        default:
                            node.Value += c;
                            break;
                    }
                }
            }

            Console.WriteLine("Output 1:");
            Print(rootNode, String.Empty);
            Console.WriteLine();
            Console.WriteLine("Output 2:");
            PrintOrdered(rootNode, String.Empty);
        }

        private static void Print(Node node, string level)
        {
            if (node.Value.Length > 0) Console.WriteLine(level + node.Value);
            foreach (Node n in node.SubNodes)
            {
                if (node.Parent == null) Print(n, "- " + level);
                else Print(n, "  " + level);
            }
        }

        
        private static void PrintOrdered(Node node, string level)
        {
            if (node.Value.Length > 0) Console.WriteLine(level + node.Value);
            foreach (Node n in node.SubNodes.OrderBy(q => q))
            {
                if (node.Parent == null) PrintOrdered(n, "- " + level);
                else PrintOrdered(n, "  " + level);
            }
        }
    }
}
