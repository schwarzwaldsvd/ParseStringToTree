﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParseStringToTree
{
    public class Node : IComparable<Node>
    {
        public Node Parent;
        public string Value;
        public List<Node> SubNodes;

        public int CompareTo(Node that)
        {
            return String.Compare(this.Value, that.Value, StringComparison.Ordinal);
        }
    }
}
