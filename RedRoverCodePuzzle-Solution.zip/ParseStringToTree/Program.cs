﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParseStringToTree
{
    class Program
    {

        static void Main()
        {
            const string inputString = "(id, name, email, type(id, name, customFields(c1, c2, c3)), externalId)";
            var rootNode = new Node
            {
                Parent = null,
                Value = string.Empty,
                SubNodes = new List<Node>()
            };
            var node = rootNode;
            var escape = false;
            foreach (var c in inputString)
            {
                if (escape)
                {
                    if (c != ' ') node.Value += c;
                    escape = false;
                }
                else
                {
                    switch (c)
                    {
                        case '(' :
                            node = new Node {Parent = node, Value = string.Empty, SubNodes = new List<Node>()};
                            node.Parent.SubNodes.Add(node);
                            break;
                        case ')' :
                            if (node.Parent != null)
                            {
                                node = new Node {Parent = node.Parent.Parent, Value = string.Empty, SubNodes = new List<Node>()};
                                node.Parent?.SubNodes.Add(node);
                            }

                            break;
                        case ',':
                            node = new Node { Parent = node.Parent, Value = string.Empty, SubNodes = new List<Node>() };
                            node.Parent?.SubNodes.Add(node);
                            escape = true;
                            break;
                        default:
                            node.Value += c;
                            break;
                    }
                }
            }

            Console.WriteLine("Output 1:");
            Print(rootNode, string.Empty, false);
            Console.WriteLine();

            Console.WriteLine("Output 2:");
            Print(rootNode, string.Empty, true);
        }

       
        private static void Print(Node node, string level, bool isOrdered)
        {
            if (node.Value.Length > 0) Console.WriteLine(level + node.Value);
            
            IEnumerable<Node> nodes = null;
            if (isOrdered) 
                nodes = node.SubNodes.OrderBy(q => q);
            else 
                nodes = node.SubNodes;
            
            foreach (var n in nodes)
            {
                if (node.Parent == null) Print(n, "- " + level, isOrdered);
                else Print(n, "  " + level, isOrdered);
            }
        }
    }
}
